export default {
    /* count: 0,
    ip: '',
    espacesVertsData: {
        categories: [],
        categoriesCount: []
    } */
    count: 0,
    trees: [],
    treesDistrict: {}
    /*,
    locationData : {
        locations : [],
        locationsCount: []
    }
    */
}
